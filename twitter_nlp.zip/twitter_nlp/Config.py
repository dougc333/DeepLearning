
#make sure this is in .gitignore!!

class Config:
    def __init__(self):
        self.consumer_key = 'eFIaiOuxsny01VVQ2QWISK1Mw'
        self.consumer_secret = 'gDQI5EiCMJJaaNI8XVNhfZXwuCOYfeJ3XsOUNHvsXqgq0Hoj9T'
        self.access_token = '76976448-Otz8w4yMKx6yCEWTH3dNTfuF8LYeLgqdoDrcl0oBK'
        self.access_secret = 'NFPFe2EzuKWuzRKmY1RENUBfQzGeGbAS1JzjX3Eu3GwDE'

