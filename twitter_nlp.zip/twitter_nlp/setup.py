from setuptools import setup

setup(name='twitter_nlp',
      version='0.1',
      description='ethan twitter stuff',
      url='http://github.com/dougc333/DeepLearning/twitter_nlp',
      author='asdf',
      author_email='asdf@asdf.com',
      packages=['ethan']
      )
